#!/bin/bash

rm -rf ~/JavaGAT-test-fileinputstream